package com.example.universalgampad

import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.concurrent.ConcurrentHashMap

data class PadState(
    val deviceName: String = "Niciun controller detectat",
    val deviceId: Int? = null,
    val buttons: Set<String> = emptySet(),
    val axes: Map<String, Float> = emptyMap(),
    val lastInput: String = "Apasă un buton sau mișcă joystickul"
)

class MainActivity : ComponentActivity() {
    private val pressed = ConcurrentHashMap.newKeySet<String>()
    private val axisValues = ConcurrentHashMap<String, Float>()
    private var deviceLabel by mutableStateOf("Niciun controller detectat")
    private var deviceIdentifier by mutableStateOf<Int?>(null)
    private var lastEvent by mutableStateOf("Conectează controllerul Bluetooth din setările Android.")
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshDevices()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                GamepadScreen(
                    deviceName = deviceLabel,
                    deviceId = deviceIdentifier,
                    buttons = pressed.toSet(),
                    axes = axisValues.toMap(),
                    lastInput = lastEvent,
                    onRefresh = { refreshDevices() }
                )
            }
        }
    }

    private fun refreshDevices() {
        val gamepads = InputDevice.getDeviceIds()
            .mapNotNull { InputDevice.getDevice(it) }
            .filter { it.sources and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK) != 0 }
        val selected = gamepads.firstOrNull()
        deviceLabel = selected?.name ?: "Niciun controller detectat"
        deviceIdentifier = selected?.id
        lastEvent = if (selected != null) "Controller detectat. Apasă butoanele pentru test." else
            "Nu este detectat niciun gamepad. Asociază-l din Setări > Bluetooth."
        refresh++
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val isGamepad = event.isFromSource(InputDevice.SOURCE_GAMEPAD) ||
            event.isFromSource(InputDevice.SOURCE_DPAD) ||
            event.isFromSource(InputDevice.SOURCE_JOYSTICK)
        if (isGamepad) {
            val label = KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
            if (event.action == KeyEvent.ACTION_DOWN) pressed.add(label)
            if (event.action == KeyEvent.ACTION_UP) pressed.remove(label)
            lastEvent = "$label: ${if (event.action == KeyEvent.ACTION_DOWN) "APĂSAT" else "ELIBERAT"}"
            refresh++
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val isJoystick = event.isFromSource(InputDevice.SOURCE_JOYSTICK) ||
            event.isFromSource(InputDevice.SOURCE_GAMEPAD)
        if (isJoystick && event.action == MotionEvent.ACTION_MOVE) {
            val names = listOf(
                MotionEvent.AXIS_X to "Stick stâng X",
                MotionEvent.AXIS_Y to "Stick stâng Y",
                MotionEvent.AXIS_Z to "Stick drept X",
                MotionEvent.AXIS_RZ to "Stick drept Y",
                MotionEvent.AXIS_HAT_X to "D-pad X",
                MotionEvent.AXIS_HAT_Y to "D-pad Y",
                MotionEvent.AXIS_LTRIGGER to "Trigger L2",
                MotionEvent.AXIS_RTRIGGER to "Trigger R2"
            )
            names.forEach { (axis, name) ->
                val value = event.getAxisValue(axis)
                if (kotlin.math.abs(value) > 0.04f) axisValues[name] = value
                else axisValues.remove(name)
            }
            deviceLabel = event.device?.name ?: deviceLabel
            deviceIdentifier = event.device?.id
            lastEvent = "Mișcare joystick detectată"
            refresh++
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }
}

@Composable
fun GamepadScreen(
    deviceName: String,
    deviceId: Int?,
    buttons: Set<String>,
    axes: Map<String, Float>,
    lastInput: String,
    onRefresh: () -> Unit
) {
    var profileName by remember { mutableStateOf("Profilul meu") }
    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Universal Gamepad Mapper", style = MaterialTheme.typography.headlineSmall)
                Text("Versiune MVP • tester controller Bluetooth", color = MaterialTheme.colorScheme.secondary)
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Controller", style = MaterialTheme.typography.titleLarge)
                        Text(deviceName, style = MaterialTheme.typography.bodyLarge)
                        Text(if (deviceId != null) "ID dispozitiv: $deviceId" else "Asociază controllerul în setările Bluetooth ale telefonului.")
                        Button(onClick = onRefresh) { Text("Rescanează dispozitivele") }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Test butoane", style = MaterialTheme.typography.titleLarge)
                        Text(lastInput, color = MaterialTheme.colorScheme.secondary)
                        if (buttons.isEmpty()) Text("Niciun buton apăsat momentan.")
                        else buttons.sorted().forEach { Text("● $it", color = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Joystick-uri și axe", style = MaterialTheme.typography.titleLarge)
                        if (axes.isEmpty()) Text("Mișcă stick-urile pentru a vedea valorile.")
                        axes.toSortedMap().forEach { (name, value) ->
                            Column {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(name)
                                    Text("%+.2f".format(value))
                                }
                                LinearProgressIndicator(
                                    progress = { ((value + 1f) / 2f).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Profil de joc (pregătire)", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = profileName,
                            onValueChange = { profileName = it },
                            label = { Text("Numele profilului") },
                            singleLine = true
                        )
                        Text("În această versiune, profilurile și maparea tactilă nu sunt încă implementate.")
                    }
                }
            }
            item {
                Text(
                    "Notă: această versiune detectează intrările standard ale controllerului când aplicația este deschisă. Nu simulează încă atingeri în alte jocuri și nu cere Wi-Fi, internet, root sau depanare USB.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}
