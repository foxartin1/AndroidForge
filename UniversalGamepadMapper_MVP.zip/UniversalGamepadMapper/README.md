# Universal Gamepad Mapper (MVP)

Primă versiune Android Studio: detectează gamepad-uri/controller-e conectate la Android și afișează evenimentele butoanelor și axelor analogice.

## Cerințe
- Android Studio recent
- JDK 17
- Android SDK 35
- Telefon Android 8.0+ (API 26+)
- Controller Bluetooth asociat în setările Android

## Deschidere și compilare
1. Dezarhivează proiectul.
2. Deschide folderul `UniversalGamepadMapper` în Android Studio.
3. Lasă Gradle Sync să se finalizeze.
4. Conectează telefonul prin USB sau folosește un emulator compatibil.
5. Apasă Run pentru instalare.

Pentru APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
APK-ul de debug va fi în `app/build/outputs/apk/debug/`.

## Limitări importante
Aceasta este o versiune MVP de testare a controllerului, nu încă un mapper universal.
Android nu permite unei aplicații obișnuite să injecteze global atingeri în alte aplicații. Pentru touch mapping între aplicații este necesar un mecanism privilegiat/ADB sau un serviciu de accesibilitate cu limitări; compatibilitatea depinde de versiunea Android și de joc. Nu există o metodă garantată de a ocoli aceste restricții fără permisiunile necesare.

Versiunea MVP nu cere Wi-Fi, internet, root, Bluetooth scan permission sau Wireless Debugging. Controllerul trebuie asociat din setările Android. Intrările standard sunt citite când aplicația este în prim-plan.
